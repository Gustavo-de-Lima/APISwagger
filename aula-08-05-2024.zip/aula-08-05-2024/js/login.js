var body = document.querySelector("body");
var signUpButton = document.querySelector("#signUp");
var singInButton = document.querySelector("#signIn");
var email = document.querySelector("#email");
var password = document.querySelector("#password");
var confirmedPassword = document.querySelector("#confirmedPassword");

body.onload = function(){
    body.className = "on-load";
}

signUpButton.addEventListener("click", function(){
    body.className = "sing-up"
    signUp()
});



function signUp() {            

    fetch("https://api-umfg-programacao-iv-2024-291d5e9a4ec4.herokuapp.com/v1/signup",
    {
        method: 'POST',
        body: JSON.stringify({
            email: email,
            password: password,
            confirmedPassword: confirmedPassword 
        }),
        headers: {
            'Content-type': 'application/json; charset=UTF-8'
        },
    })
    .then(response => {
        if(response.status == 200){
            alert('Sucesso no cadastro')
            window.location.href = 'welcome.html?email=' + encodeURIComponent(email)
          }else{
            alert('Erro no cadastro')
          }
        })         
    .catch(error => {console.log(error)})
}

